# Fiverr Gig Showcase — Deployment Guide

A 4-file, no-dependency site: plain HTML/CSS/JS plus one PHP page and one
PHP form handler. No framework, no build step, no Composer packages
required to run it.

## 1. File structure

```
fiverr-showcase-site/
├── index.php           # Main page (HTML + a couple of small PHP snippets)
├── style.css            # All styling
├── script.js             # Mobile nav, smooth scroll, contact form (fetch)
├── send-message.php       # Contact form handler (validates + emails you)
└── README.md               # This file
```

All four files must stay in the **same folder** — `style.css` and
`script.js` are linked with relative paths, and the form in `index.php`
posts to `send-message.php` by filename, not by full URL.

## 2. Before you touch a server: edit one file

Open **`send-message.php`** and change these two lines near the top:

```php
define('TO_EMAIL', 'you@example.com');   // <-- your real inbox
define('SITE_NAME', 'Your Website');     // <-- shown as the email "From" name
```

That's the only required edit. Everything else works as-is.

## 3. Test it locally before pushing live

You already have PHP and VS Code, so the fastest path is PHP's built-in
development server — no Apache/XAMPP install needed.

**On Linux (your setup):**

```bash
# from inside the fiverr-showcase-site folder
php -S localhost:8000
```

Then open `http://localhost:8000/index.php` in your browser.

**If `php` isn't installed yet:**

```bash
sudo apt update
sudo apt install php-cli
```

**Alternative (if you prefer a full local Apache/MySQL stack):**
XAMPP, MAMP, or Laragon all work the same way — drop the folder into
`htdocs/` (XAMPP) or the equivalent, start Apache, and visit
`http://localhost/fiverr-showcase-site/`.

### About testing the contact form locally

PHP's built-in server (and most local installs) usually has **no mail
server configured**, so `mail()` will fail locally even though the code
is correct — you'll see the friendly "Something went wrong sending your
message" error instead of a real email. That's expected. To verify the
logic itself locally without real email, you can temporarily add this
line near the top of `send-message.php` for testing only, then remove it:

```php
// TEMPORARY — for local testing only, remove before deploying
error_log(print_r($_POST, true));
```

Then check your terminal / PHP error log to confirm the form data is
arriving and passing validation correctly. Remove the line again before
you deploy.

The **real** end-to-end test (form → actual email in your inbox) should
happen after step 4, once the site is on a host with mail configured.

## 4. Going live

### Option A — Shared hosting (simplest, works with the code as-is)

Most budget hosts (Hostinger, Namecheap, Bluehost, etc.) run Apache or
LiteSpeed with PHP and a working `sendmail` out of the box, so
`send-message.php` will typically work immediately after upload.

1. Upload all four files to your hosting account's public folder
   (usually `public_html/` or `htdocs/`) via the host's File Manager or
   FTP (FileZilla).
2. Visit your domain and submit the form once with a real email address
   to confirm delivery — check your spam folder the first time.
3. If email doesn't arrive within a few minutes, see "If email doesn't
   arrive" below.

### Option B — VPS / your own server

1. Make sure PHP 7.4+ is installed with Apache or Nginx configured to
   run `.php` files (not just serve them as static text).
2. Upload the files the same way (`scp`, `rsync`, or git).
3. Confirm a mail transport agent is installed (`sendmail` or `postfix`)
   — a fresh VPS often does **not** have one by default:
   ```bash
   sudo apt install sendmail
   ```

### If email doesn't arrive (common on both options above)

`mail()` is simple but unreliable for actual delivery on a lot of hosts
— messages can silently land in spam or get dropped by the receiving
server entirely. If that happens, swap `mail()` for
**[PHPMailer](https://github.com/PHPMailer/PHPMailer)** with real SMTP
credentials (your host's SMTP, Gmail app password, SendGrid, Mailgun,
etc.) — it's a five-minute change confined entirely to the "6. Send"
section near the bottom of `send-message.php`; nothing else in the
project needs to change.

## 5. A couple of optional hardening steps for later

Not required to launch, worth doing once the site is live and getting
real traffic:

- **Force HTTPS** — most hosts offer a free SSL certificate (Let's
  Encrypt); once installed, add this to a `.htaccess` file in the same
  folder:
  ```apache
  RewriteEngine On
  RewriteCond %{HTTPS} off
  RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
  ```
- **Basic rate limiting** — if you start getting spam despite the
  honeypot, you can track submission timestamps in the PHP session and
  reject anything faster than, say, one submission per 30 seconds.

## 6. Quick pre-launch checklist

- [ ] `TO_EMAIL` and `SITE_NAME` updated in `send-message.php`
- [ ] Tested the page locally with `php -S localhost:8000`
- [ ] Tested the contact form after deploying live, with a real inbox
- [ ] Checked spam folder on first live test
- [ ] Confirmed the mobile menu opens/closes on an actual phone (or
      Chrome DevTools device toolbar)
- [ ] Checked the page in Chrome, Firefox, and Safari
