<?php
/**
 * index.php
 * -----------------------------------------------------------------------
 * Showcase / landing page for the "Responsive Website with HTML, CSS,
 * JavaScript & PHP" Fiverr gig.
 *
 * Why this is a .php file and not plain .html:
 *  - The footer year is generated with PHP (date('Y')) instead of being
 *    hard-coded, so the page never goes stale.
 *  - The contact form below carries a one-time PHP session token that
 *    send-message.php checks before it will process a submission — a
 *    lightweight defence against automated/replayed form spam.
 *
 * Everything else on this page is static markup; there is no database
 * and no other server-side logic here on purpose, so the file stays easy
 * to read and safe to hand off to a non-technical client.
 * -----------------------------------------------------------------------
 */

// A fresh, random, single-use token per page load.
// send-message.php will only accept a submission whose token matches
// the one stored in the session, and it deletes it after one use.
session_start();
$contactToken = bin2hex(random_bytes(16));
$_SESSION['contact_token'] = $contactToken;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Clean, Modern, Fully Responsive Websites — HTML, CSS, JS &amp; PHP Developer</title>
  <meta name="description" content="Custom-coded, fully responsive websites built with HTML5, CSS3, JavaScript, and PHP — no page builders, no bloated templates. Responsive design, bug fixes, and a working PHP contact form included.">

  <!-- Open Graph -->
  <meta property="og:type" content="website">
  <meta property="og:title" content="Clean, Modern, Fully Responsive Websites">
  <meta property="og:description" content="Custom-coded HTML5, CSS3, JavaScript &amp; PHP websites — responsive on desktop, tablet, and mobile.">
  <meta name="theme-color" content="#12172a">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=IBM+Plex+Sans:wght@400;500;600&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="style.css">
</head>
<body>

  <a class="skip-link" href="#main">Skip to content</a>

  <header class="site-header" id="top">
    <div class="header-inner">
      <a href="#top" class="logo">build<span class="logo-dot">.</span>dev</a>

      <nav class="nav" id="primaryNav" aria-label="Primary">
        <a href="#included">What's included</a>
        <a href="#approach">Approach</a>
        <a href="#package">Package</a>
        <a href="#contact">Contact</a>
      </nav>

      <a href="#contact" class="btn btn-primary btn-small header-cta">Message me</a>

      <button
        type="button"
        class="nav-toggle"
        id="navToggle"
        aria-expanded="false"
        aria-controls="primaryNav"
        aria-label="Toggle navigation menu"
      >
        <span></span><span></span><span></span>
      </button>
    </div>
  </header>

  <main id="main">

    <!-- ============================= HERO ============================= -->
    <section class="hero">
      <div class="section-inner hero-inner">
        <div class="hero-copy">
          <h1>Clean, Modern, and Fully Responsive Websites</h1>
          <p class="hero-sub">
            I build small-business and personal websites by hand with HTML5,
            CSS3, JavaScript, and PHP — no page builders, no bloated
            templates. Every layout gets checked on desktop, tablet, and
            phone before it ships.
          </p>
          <div class="hero-actions">
            <a href="#contact" class="btn btn-primary">Message me before ordering</a>
            <a href="#included" class="btn btn-ghost">See what's included</a>
          </div>
        </div>

        <div class="hero-visual" aria-hidden="true">
          <div class="device device-desktop">
            <div class="device-bar">
              <span></span><span></span><span></span>
            </div>
            <div class="device-screen">
              <div class="mock-block mock-hero"></div>
              <div class="mock-block mock-line"></div>
              <div class="mock-block mock-line short"></div>
              <div class="mock-cards">
                <div></div><div></div><div></div>
              </div>
            </div>
          </div>

          <div class="device device-tablet">
            <div class="device-screen">
              <div class="mock-block mock-hero"></div>
              <div class="mock-block mock-line"></div>
              <div class="mock-block mock-line short"></div>
            </div>
          </div>

          <div class="device device-phone">
            <div class="device-screen">
              <div class="mock-block mock-hero"></div>
              <div class="mock-block mock-line short"></div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ========================= WHAT'S INCLUDED ======================= -->
    <section class="included" id="included">
      <div class="section-inner">
        <h2>What's included in every build</h2>
        <p class="section-lede">Six things every site leaves with, no matter which page you're building.</p>

        <div class="feature-grid">

          <article class="feature-card">
            <svg class="feature-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <rect x="2" y="3" width="20" height="13" rx="2" stroke="currentColor" stroke-width="1.6"/>
              <path d="M8 21h8M12 16v5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
            </svg>
            <h3>Custom responsive design</h3>
            <p>Laid out and tested for desktop, tablet, and phone — not just shrunk to fit.</p>
          </article>

          <article class="feature-card">
            <svg class="feature-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M4 3l1.6 17L12 22l6.4-2L20 3H4z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>
              <path d="M8 8h8M8.5 12h7M9 16h6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
            </svg>
            <h3>Clean HTML5 &amp; CSS3</h3>
            <p>Semantic markup and organized stylesheets, so the site stays easy to edit later.</p>
          </article>

          <article class="feature-card">
            <svg class="feature-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M4 5l6 7-6 7M13 19h7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <h3>JavaScript interactivity</h3>
            <p>Menus, smooth scrolling, and small interactions that make the site feel finished.</p>
          </article>

          <article class="feature-card">
            <svg class="feature-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <rect x="3" y="5" width="18" height="14" rx="2" stroke="currentColor" stroke-width="1.6"/>
              <path d="M3 7l9 6 9-6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <h3>PHP form integration</h3>
            <p>Contact and inquiry forms that actually send email, validated on both ends.</p>
          </article>

          <article class="feature-card">
            <svg class="feature-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6"/>
              <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <h3>Layout &amp; bug fixes</h3>
            <p>Checked for broken spacing, overlapping text, and alignment issues before delivery.</p>
          </article>

          <article class="feature-card">
            <svg class="feature-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6"/>
              <path d="M3 12h18M12 3c2.5 2.5 3.8 5.7 3.8 9s-1.3 6.5-3.8 9c-2.5-2.5-3.8-5.7-3.8-9S9.5 5.5 12 3z" stroke="currentColor" stroke-width="1.6"/>
            </svg>
            <h3>Cross-browser compatibility</h3>
            <p>Tested in Chrome, Firefox, and Safari, so it looks right no matter how visitors arrive.</p>
          </article>

        </div>
      </div>
    </section>

    <!-- ======================= TECH STACK / APPROACH =================== -->
    <section class="stack-strip" id="approach">
      <div class="section-inner stack-inner">
        <div class="stack-copy">
          <h2>Built with code you can hand to anyone</h2>
          <p>
            No page-builder lock-in and no plugin graveyard — just HTML,
            CSS, JavaScript, and PHP that a future developer can actually
            read. This page is a live example: the menu, the smooth
            scrolling, and the contact form below all run on the exact
            stack described here.
          </p>
        </div>
        <ul class="stack-pills">
          <li><code>HTML5</code></li>
          <li><code>CSS3</code></li>
          <li><code>JavaScript</code></li>
          <li><code>PHP</code></li>
        </ul>
      </div>
    </section>

    <!-- =========================== WHY WORK WITH ME ==================== -->
    <section class="values">
      <div class="section-inner">
        <h2>Why work with me</h2>
        <div class="values-grid">

          <div class="value-item">
            <h3>Quality work with attention to detail</h3>
            <p>Spacing, alignment, and small details get checked before anything is marked done.</p>
          </div>

          <div class="value-item">
            <h3>Fast response &amp; clear communication</h3>
            <p>You'll know what's happening at every stage, without having to ask.</p>
          </div>

          <div class="value-item">
            <h3>On-time delivery</h3>
            <p>The date we agree on at the start is the date you get your files.</p>
          </div>

          <div class="value-item">
            <h3>100% satisfaction guaranteed</h3>
            <p>If something's not right, I'll fix it until it is.</p>
          </div>

        </div>
      </div>
    </section>

    <!-- ============================= PACKAGE ============================ -->
    <section class="package" id="package">
      <div class="section-inner package-inner">
        <div class="package-card">
          <p class="package-tier">Standard package</p>
          <p class="package-price">$80</p>

          <ul class="package-list">
            <li>Custom responsive design (desktop, tablet, mobile)</li>
            <li>Clean HTML5 &amp; CSS3 build</li>
            <li>JavaScript interactivity — navigation, scroll, small UI touches</li>
            <li>One PHP-powered form (contact / inquiry), with validation</li>
            <li>Cross-browser testing and layout fixes</li>
          </ul>

          <p class="package-note">
            Delivery time and revisions are confirmed once we've talked
            through your project — every site is a little different.
          </p>

          <a href="#contact" class="btn btn-primary btn-block">Message me before ordering</a>
        </div>
      </div>
    </section>

    <!-- ============================= CONTACT ============================ -->
    <section class="contact" id="contact">
      <div class="section-inner contact-inner">

        <div class="contact-copy">
          <h2>Message me before placing an order</h2>
          <p>
            Tell me about your project — what the site is for, roughly how
            many pages, and anything you already have (a domain, a logo,
            existing content). I'll reply with honest scope and timing
            before you spend anything.
          </p>
        </div>

        <form id="contactForm" class="contact-form" action="send-message.php" method="post" novalidate>

          <input type="hidden" name="token" value="<?php echo htmlspecialchars($contactToken, ENT_QUOTES, 'UTF-8'); ?>">

          <!-- Honeypot: real visitors never see or fill this field.
               Simple bots that auto-fill every input usually do. -->
          <div class="hp-field" aria-hidden="true">
            <label for="website">Leave this field empty</label>
            <input type="text" id="website" name="website" tabindex="-1" autocomplete="off">
          </div>

          <div class="form-row">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required maxlength="80" autocomplete="name">
          </div>

          <div class="form-row">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required maxlength="120" autocomplete="email">
          </div>

          <div class="form-row">
            <label for="project_type">Project type</label>
            <select id="project_type" name="project_type" required>
              <option value="" disabled selected>Select one</option>
              <option value="business">Business website</option>
              <option value="portfolio">Personal / portfolio site</option>
              <option value="landing">Landing page</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div class="form-row">
            <label for="message">Project details</label>
            <textarea id="message" name="message" rows="5" required maxlength="2000"></textarea>
          </div>

          <button type="submit" class="btn btn-primary btn-block" id="submitBtn">Send message</button>

          <p class="form-status" id="formStatus" role="status" aria-live="polite"></p>
        </form>
      </div>
    </section>

  </main>

  <footer class="site-footer">
    <div class="section-inner footer-inner">
      <p>&copy; <?php echo date('Y'); ?> — Built with HTML, CSS, JavaScript, and PHP.</p>
      <a href="#top" class="back-to-top">Back to top</a>
    </div>
  </footer>

  <script src="script.js"></script>
</body>
</html>
