/**
 * script.js
 * -------------------------------------------------------------------------
 * Three small, purposeful behaviours — no framework, no build step:
 *   1. Mobile navigation toggle (hamburger <-> close, closes on link click)
 *   2. Smooth scrolling to in-page sections, with reduced-motion respected
 *   3. Contact form submission via fetch(), talking to send-message.php
 *      without a full page reload, with inline success/error feedback
 * -------------------------------------------------------------------------
 */

document.addEventListener('DOMContentLoaded', function () {
  initMobileNav();
  initSmoothScroll();
  initContactForm();
  initHeaderShadow();
});

/* ------------------------------------------------------------------ */
/* 1. Mobile navigation                                                */
/* ------------------------------------------------------------------ */

function initMobileNav() {
  var toggle = document.getElementById('navToggle');
  var nav = document.getElementById('primaryNav');

  if (!toggle || !nav) return;

  function closeNav() {
    nav.classList.remove('is-open');
    toggle.setAttribute('aria-expanded', 'false');
  }

  function openNav() {
    nav.classList.add('is-open');
    toggle.setAttribute('aria-expanded', 'true');
  }

  toggle.addEventListener('click', function () {
    var isOpen = nav.classList.contains('is-open');
    if (isOpen) {
      closeNav();
    } else {
      openNav();
    }
  });

  // Close the menu once a link inside it is used
  nav.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', closeNav);
  });

  // Close the menu if someone clicks outside of it
  document.addEventListener('click', function (event) {
    var clickedInsideNav = nav.contains(event.target);
    var clickedToggle = toggle.contains(event.target);
    if (!clickedInsideNav && !clickedToggle) {
      closeNav();
    }
  });

  // Close on Escape for keyboard users
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      closeNav();
      toggle.focus();
    }
  });
}

/* ------------------------------------------------------------------ */
/* 2. Smooth scrolling                                                 */
/* ------------------------------------------------------------------ */

function initSmoothScroll() {
  var prefersReducedMotion = window.matchMedia(
    '(prefers-reduced-motion: reduce)'
  ).matches;

  var links = document.querySelectorAll('a[href^="#"]');

  links.forEach(function (link) {
    link.addEventListener('click', function (event) {
      var targetId = link.getAttribute('href');
      if (!targetId || targetId === '#') return;

      var target = document.querySelector(targetId);
      if (!target) return;

      event.preventDefault();

      target.scrollIntoView({
        behavior: prefersReducedMotion ? 'auto' : 'smooth',
        block: 'start',
      });

      // Keep keyboard focus in a sensible place after the jump
      target.setAttribute('tabindex', '-1');
      target.focus({ preventScroll: true });
    });
  });
}

/* ------------------------------------------------------------------ */
/* 3. Contact form (fetch -> send-message.php)                         */
/* ------------------------------------------------------------------ */

function initContactForm() {
  var form = document.getElementById('contactForm');
  var status = document.getElementById('formStatus');
  var submitBtn = document.getElementById('submitBtn');

  if (!form || !status || !submitBtn) return;

  form.addEventListener('submit', function (event) {
    event.preventDefault();

    if (!form.checkValidity()) {
      // Let the browser show its native validation messages
      form.reportValidity();
      return;
    }

    setLoadingState(true);
    setStatus('', null);

    var formData = new FormData(form);

    fetch(form.getAttribute('action'), {
      method: 'POST',
      body: formData,
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
    })
      .then(function (response) {
        return response.json().then(function (data) {
          return { ok: response.ok, data: data };
        });
      })
      .then(function (result) {
        if (result.ok && result.data.success) {
          setStatus(result.data.message, 'success');
          form.reset();
        } else {
          setStatus(
            result.data.message ||
              'Something went wrong. Please try again.',
            'error'
          );
        }
      })
      .catch(function () {
        setStatus(
          'Network error — please check your connection and try again.',
          'error'
        );
      })
      .finally(function () {
        setLoadingState(false);
      });
  });

  function setLoadingState(isLoading) {
    submitBtn.disabled = isLoading;
    submitBtn.textContent = isLoading ? 'Sending…' : 'Send message';
  }

  function setStatus(message, type) {
    status.textContent = message;
    status.classList.remove('is-success', 'is-error');
    if (type === 'success') status.classList.add('is-success');
    if (type === 'error') status.classList.add('is-error');
  }
}

/* ------------------------------------------------------------------ */
/* Small functional touch: header gets a subtler background once the   */
/* page has scrolled, so it reads as "layered" instead of floating     */
/* ------------------------------------------------------------------ */

function initHeaderShadow() {
  var header = document.querySelector('.site-header');
  if (!header) return;

  function update() {
    if (window.scrollY > 8) {
      header.style.boxShadow = '0 12px 24px rgba(0, 0, 0, 0.18)';
    } else {
      header.style.boxShadow = 'none';
    }
  }

  update();
  window.addEventListener('scroll', update, { passive: true });
}
