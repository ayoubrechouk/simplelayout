<?php
/**
 * send-message.php
 * -------------------------------------------------------------------------
 * Handles the contact form on index.php.
 *
 * What this file does, in order:
 *   1. Only accepts POST requests.
 *   2. Checks a honeypot field to quietly drop simple spam bots.
 *   3. Checks a one-time session token so the form can't be replayed by
 *      an automated script that never actually loaded the page.
 *   4. Validates and sanitizes every field.
 *   5. Strips CR/LF from anything that goes into an email header, to
 *      prevent header-injection / email-spoofing attacks.
 *   6. Sends the email and returns a JSON response for script.js to show.
 *
 * -------------------------------------------------------------------------
 * BEFORE YOU DEPLOY THIS — edit the two constants directly below.
 * -------------------------------------------------------------------------
 */

// ---------------------------------------------------------------------
// EDIT THESE TWO LINES before putting the site live:
// ---------------------------------------------------------------------
define('TO_EMAIL', 'you@example.com');   // <-- your real inbox
define('SITE_NAME', 'Your Website');     // <-- shown as the email "From" name
// ---------------------------------------------------------------------

session_start();

header('Content-Type: application/json; charset=utf-8');

// ---- 1. Only POST is allowed ----------------------------------------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'This endpoint only accepts form submissions.',
    ]);
    exit;
}

// ---- 2. Honeypot check -------------------------------------------------
// Real visitors never see or fill the "website" field (it's hidden with
// CSS, not hidden with the `hidden` attribute, since some bots skip
// obviously-hidden inputs but still fill plain text inputs). If it has a
// value, this was almost certainly submitted by a bot.
if (!empty(trim($_POST['website'] ?? ''))) {
    // Respond as if it worked so the bot doesn't learn the field is a trap,
    // but never actually send anything.
    echo json_encode([
        'success' => true,
        'message' => 'Thanks! Your message has been sent.',
    ]);
    exit;
}

// ---- 3. One-time CSRF-style token check --------------------------------
$submittedToken = $_POST['token'] ?? '';
$sessionToken   = $_SESSION['contact_token'] ?? '';

if ($submittedToken === '' || $sessionToken === '' || !hash_equals($sessionToken, $submittedToken)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Your session expired. Please refresh the page and try again.',
    ]);
    exit;
}

// Token is single-use: remove it immediately so it can't be replayed.
unset($_SESSION['contact_token']);

// ---- 4. Collect + sanitize ----------------------------------------------

/**
 * Trim whitespace and strip any HTML/script tags from a raw POST value.
 */
function clean_text(string $value): string
{
    return trim(strip_tags($value));
}

/**
 * Character-count helper that works even if the optional mbstring
 * extension isn't enabled (some minimal/shared hosts don't have it).
 */
function safe_strlen(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

$name        = clean_text($_POST['name'] ?? '');
$email       = trim($_POST['email'] ?? '');
$projectType = clean_text($_POST['project_type'] ?? '');
$message     = clean_text($_POST['message'] ?? '');

$allowedProjectTypes = ['business', 'portfolio', 'landing', 'other'];

$errors = [];

if ($name === '' || safe_strlen($name) > 80) {
    $errors[] = 'Please enter a valid name.';
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || safe_strlen($email) > 120) {
    $errors[] = 'Please enter a valid email address.';
}

if (!in_array($projectType, $allowedProjectTypes, true)) {
    $errors[] = 'Please select a project type.';
}

if ($message === '' || safe_strlen($message) > 2000) {
    $errors[] = 'Please add a short project description (under 2000 characters).';
}

if (!empty($errors)) {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'message' => implode(' ', $errors),
    ]);
    exit;
}

// ---- 5. Build the email safely -------------------------------------------

// Strip any stray line breaks from values that end up in headers, so a
// malicious "name" or "email" can't inject extra headers (classic PHP
// mail() header-injection attack).
$safeName  = preg_replace('/[\r\n]+/', ' ', $name);
$safeEmail = preg_replace('/[\r\n]+/', '', $email);

$projectLabels = [
    'business'  => 'Business website',
    'portfolio' => 'Personal / portfolio site',
    'landing'   => 'Landing page',
    'other'     => 'Other',
];

$subject = 'New project inquiry from ' . $safeName;

$body  = "New message from your website contact form:\n\n";
$body .= "Name: {$safeName}\n";
$body .= "Email: {$safeEmail}\n";
$body .= 'Project type: ' . ($projectLabels[$projectType] ?? $projectType) . "\n\n";
$body .= "Message:\n{$message}\n";

$hostForFrom = preg_replace('/[^a-zA-Z0-9.\-]/', '', $_SERVER['SERVER_NAME'] ?? 'example.com');

$headers   = [];
$headers[] = 'From: ' . SITE_NAME . ' <no-reply@' . $hostForFrom . '>';
$headers[] = 'Reply-To: ' . $safeEmail;
$headers[] = 'X-Mailer: PHP/' . phpversion();
$headers[] = 'Content-Type: text/plain; charset=UTF-8';

// ---- 6. Send ---------------------------------------------------------------

/*
 * NOTE ON mail():
 * PHP's built-in mail() depends entirely on the server having a working
 * mail transport agent (sendmail/postfix) configured. Most shared hosting
 * supports this out of the box. Local dev servers (php -S, XAMPP, MAMP)
 * usually do NOT send real email unless you configure one yourself.
 *
 * For production, using PHPMailer with real SMTP credentials (your host's
 * SMTP, Gmail, SendGrid, Mailgun, etc.) is much more reliable and far less
 * likely to be marked as spam. See README.md for both setups.
 */
$sent = @mail(TO_EMAIL, $subject, $body, implode("\r\n", $headers));

if ($sent) {
    echo json_encode([
        'success' => true,
        'message' => "Thanks, {$safeName}! Your message is on its way — I'll reply soon.",
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Something went wrong sending your message. Please try again or email me directly.',
    ]);
}
